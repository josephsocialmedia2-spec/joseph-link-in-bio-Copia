# REAL MEDIA PRO — Archivio ufficiale della Brand Identity

Archivio fornito dall’utente il 27/10/2026: **38 file originali (28 immagini distinte)**.
Sono conservati 28 WebP ad alta qualità; i 10 duplicati byte-per-byte sono riportati nel `manifest.json` con nomi e hash. Gli originali PNG integrali sono disponibili nel file sorgente ZIP dell’utente e nell’archivio originale separato.

## Gerarchia visiva
- **Brand master**: `Real Media Pro_ strategie digitali alpine.png` — logo delle montagne, blu/bianco, Valle di Susa, struttura ordinata.
- `web_ui_reference`: riferimento per landing e UI, NON matrice per grafica social.
- `editorial_reference`: esempi di volantini e post, anche affollati; NON riprodurre densità, errori o numeri non verificati.
- `partner_reference_only`: il visual del partner Immobiliare La Sacra è solo riferimento e non autorizza l’uso o la generazione del suo logo.

## Regole vincolanti
Usare `brand.json` come autorità per palette, tipografia, formato, CTA e contatti. Un singolo messaggio dominante, testi grandi, niente prezzi immobiliari inventati o dati locali non supportati. In caso di generazione AI, ogni singola slide deve essere revisionata e confrontata con il master.

## Ruoli
REAL MEDIA PRO/Joseph cura il marketing; la mediazione e le valutazioni professionali spettano a Immobiliare La Sacra tramite i propri agenti abilitati. Le CTA usano esclusivamente i contatti di Joseph.

## File
- `brand.json` specifiche verificabili dalla pipeline
- `manifest.json` inventario deduplicato di tutte le immagini incluse nello ZIP originale
- `immagini/` 28 versioni WebP ad alta qualità, riferimenti grafici
- `anteprima.jpg` contact sheet dell'archivio
